# vulnerable-php-code-examples
Examples of vulnerable PHP code
