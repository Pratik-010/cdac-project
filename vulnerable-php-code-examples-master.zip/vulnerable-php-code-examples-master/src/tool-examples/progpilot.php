<?php

$var7 = $_GET["p"];
$var4 = $var7;
echo "$var4";